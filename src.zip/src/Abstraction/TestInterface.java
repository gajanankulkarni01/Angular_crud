package Abstraction;

public interface TestInterface {

	int a = 10; // public final abstract
	public void Display();
}
