package Abstraction;


public class AbstractClassDemo implements TestInterface{
	
	public static void main(String[] args) {
		
	}

	@Override
	public void Display() {
		
	}


}