package Inheritance;

public class ClassA {

	public void Add(int a, int b)
	{
		System.out.println(a+b);
	}
	
}
