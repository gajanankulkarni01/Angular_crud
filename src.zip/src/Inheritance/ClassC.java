package Inheritance;

public class ClassC extends ClassA{

	public static void main(String[] args) {
		ClassC g = new ClassC();
		g.Add(10, 5);

	}

}
