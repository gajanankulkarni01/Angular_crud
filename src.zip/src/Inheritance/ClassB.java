package Inheritance;

public class ClassB extends ClassA{
	public void Add(int a, int b)
	{
		System.out.println(a+b);
	}

}
