
public class LoopPrograms {

	public static void main(String[] args) {
		int age=11;
		
		
		//break
		for(int i=1; i<=5; i++) {
			if(i == 3)
			{
				System.out.println("Continue loop");
				continue;
			}
			
			/*System.out.println(i);*/
		}
		
		
		
		
	/*	do {
			System.out.println(age);
			age++;
		}while(age <10);
		*/
		
		/*//While Loop
		while(true)
		{
			System.out.println(age);
			age++;
		}*/
		
		
		
		//for(variable declaration; condition; increment)
	/*	for(int i=1; i<=10;i++)
		{
			System.out.println(i);
		}*/
		
		
		
		/*switch(age) {
		
		case 5:
			System.out.println();
		}*/
	/*	if(age > 5 && age < 15)
		{
			System.out.println("small boy");
		}
		else if(age >= 15 && age < 18)
		{
			System.out.println("Teen Age Boy");
		}
		else if(age > 18)
		{
			System.out.println("Adult");
		}
		else
		{
			System.out.println("Not Valid Criteria");
		}
*/
		
		
	}

}
