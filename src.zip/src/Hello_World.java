
public class Hello_World {
	static int a = 40;
	int rahul = 100;
	//static int prasad = 26; //declaration + assignment
	static int prasad;
	
	String abc="Gajanan";
	public static void main(String[] args) {
		Hello_World.a = 50;
		Hello_World h= new Hello_World();
		h.Add(10, 15);
		Hello_World.prasad = 100;
		int gaja =20;
		System.out.println(Hello_World.a);
	}

	//return type - Method will return this kind of response
	public int Add(int a, int b)
	{
		int c =a+b;
		return c;
	}

}

class Hello_World2{
	
}

class Hello_World3{
	
}