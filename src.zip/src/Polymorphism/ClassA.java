package Polymorphism;

public class ClassA {

	int a = 10;
	public void Add(int a, int b)
	{
		System.out.println("Inside ClassA");
	}
}
