package Polymorphism;

public class ClassB extends ClassA{
	
	//Method Overriding
	//Rule 1 - Method Signature should same
	//Rule 2 - Method return type should same or covariant return allowed
	//Rule 3 - Different class and 1st class should  Extends 2nd class
	//We cant override variables
	//Runttime polymorphism
	//int a  = 20;
	public void Add(int a, int b)
	{
		System.out.println("Inside ClassB");
	}
	
	public static void main(String[] args) {
	ClassB c = new ClassB();

	}

}
