package Polymorphism;

public class MethodOverloading {

	//Rule 1 - Method Name should be same
	//Rule 2 - return type doestn't matter
	//Rule 3 - Method parameters should be different
	//Rule 4 - All methods must be in the same class
	//Compile time polymorphism
	
	public void Add(int a, int b)
	{
		System.out.println(a+b);
	}
	
	public void Add(int a, int b, int c)
	{
		System.out.println(a+b+c);
	}
	
	public int Add(int a, int b, int c, int d)
	{
		System.out.println(a+b+c+d);
		return a+b+c+d;
	}
	
	public int Subtract(int a, int b, int c, int d)
	{
		System.out.println(a-b-c-d);
		return a-b-c-d;
	}
	
	public static void main(String agrs[])
	{
		MethodOverloading m = new MethodOverloading();
		m.Add(10, 20);
		m.Add(10, 20, 30);
		m.Add(10, 20, 30, 40);
	}
}
